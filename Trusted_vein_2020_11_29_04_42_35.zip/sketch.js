var monkey=  createSprite(36,355,20,20);

monkey.setAnimation("monkey");
monkey.scale=0.1;
var ground= createSprite(198,366,800,10);
ground.velocityX=-2

var stoneGroup = createGroup()
var count =0
ground.shapeColor=("red")
var  bananaGroup = createGroup();
var PLAY = 1;
var END = 0;
var gameState = PLAY;
var count = 0
function draw() {
   background(255);
   text(count,329,86)
  if (gameState === PLAY) {
    
    if (ground.x < 0){
      ground.x = ground.width/2;
    }
    ground.velocityX = -(6 + 3*count/100);
     if(keyDown("space")){
      monkey.velocityY = -12 ;
      
    }
     monkey.velocityY = monkey.velocityY + 0.8;
     
      monkey.collide(ground);
      
      spawnObstacles() 
      
    spawnBanana()
    
    if (stoneGroup.isTouching(monkey)) {
      text("GAME OVER",177,259)
      gameState = END
      
    }
     if (bananaGroup.isTouching(monkey)) {
      count = count+1
      
    }
    
  } else if(gameState===END){
   if (stoneGroup.isTouching(monkey)) {
     textSize(20)
      text("GAME OVER",177,259)
      
      
    }
    
    //set velcity of each game object to 0
    ground.velocityX = 0;
    monkey.velocityY = 0;
    bananaGroup.setVelocityXEach(0);
    stoneGroup.setVelocityXEach(0);
    
    //change the trex animation
    
    
    //set lifetime of the game objects so that they are never destroyed
    bananaGroup.setLifetimeEach(-1);
    stoneGroup.setLifetimeEach(-1);
  }
  
  
 
   
  
drawSprites();
   
  
}
function spawnObstacles() {
  if(World.frameCount % 60 === 0) {
    var stone = createSprite(400,350,10,40);
    stone.velocityX = -(6 + 3*count/100);
    //generate random obstacles
    var rand = randomNumber(1,6);
    stone.setAnimation("Stone");
    
    //assign scale and lifetime to the obstacle           
    stone.scale = 0.1;
    stone.lifetime = 70;
    //add each obstacle to the group
    stoneGroup.add(stone);
  }
}
function spawnBanana() {
  //write code here to spawn the clouds
  if (World.frameCount % 60 === 0) {
    var banana = createSprite(142,randomNumber(170,280),40,10);
    
    banana.setAnimation("Banana" );
    banana.scale = 0.05;
    banana.velocityX = -3;
    
     //assign lifetime to the variable
    banana.lifetime = 134;
    
    //adjust the depth
  
    
    //add each cloud to the group
    bananaGroup.add(banana);
  }
  
}

